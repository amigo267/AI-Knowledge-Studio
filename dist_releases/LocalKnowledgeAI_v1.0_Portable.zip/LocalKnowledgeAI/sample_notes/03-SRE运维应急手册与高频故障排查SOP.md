# ⚡ SRE 运维应急手册与高频故障排查 SOP

> **文档适用角色**：SRE 运维工程师、技术支持专家、系统架构师  
> **核心原则**：先止血、后定位、再复盘。所有线上操作务必遵守双人复核制度。

---

## 一、故障排查决策流图

```mermaid
graph TD
    Alert["🚨 监控告警: 接口 502/504 激增或数据库 CPU 满载"] --> Check1{"检查网关 Nginx 错误日志"}
    Check1 -->|"连接拒绝: connect failed"| ProcDown["上游微服务崩溃或端口未监听"]
    Check1 -->|"超时报警: upstream timed out"| Timeout["后端慢查询或高并发死锁阻塞"]
    ProcDown --> Action1["执行 systemctl 检查进程与内核 OOM 状态"]
    Timeout --> CheckDB{"排查 MySQL 慢查询与活动会话"}
    CheckDB -->|"存在长事务与锁争用"| Action2["SHOW FULL PROCESSLIST 并紧急终止查询"]
    CheckDB -->|"CPU 持续 100% 但无死锁"| Action3["开启限流降级并排查 Redis 击穿"]
    Action1 --> Verify["健康检查接口探测恢复"]
    Action2 --> Verify
    Action3 --> Verify
```

---

## 二、SOP-01: HTTP 502 Bad Gateway 紧急定位与止血

### 1. 现象说明
当用户访问前端页面出现 `502 Bad Gateway` 时，表明反向代理（Nginx）无法与后端应用建立 TCP 连接或被重置。

### 2. 诊断命令清单（按顺序执行）
```bash
# 步骤 1：确认反向代理日志具体错误原因
tail -n 50 /var/log/nginx/error.log | grep -E "502|connect\(\) failed"

# 步骤 2：检查后端服务端口（以 8000 为例）是否存活
ss -tulpn | grep :8000

# 步骤 3：查看后端服务是否遭遇 Linux 内核 OOM-Killer（内存耗尽强杀）
dmesg -T | grep -i "oom_killer\|killed process"

# 步骤 4：查看系统资源瞬时负载
top -b -n 1 | head -n 20
```

### 3. 应急修复步骤
1. 若由于后端应用无响应崩溃：
   ```bash
   # 重启应用服务
   sudo systemctl restart my-web-app.service
   # 观察实时输出 30 秒
   journalctl -u my-web-app.service -f -n 50
   ```
2. 若为内存泄漏导致 OOM，临时拉起备用实例并接入 Nginx upstream 权重分流，立即安排热 dump 堆栈分析。

---

## 三、SOP-02: 生产 MySQL 实例 CPU 突发 100% 排查指南

### 1. 核心排查 SQL 语句
在应急终端登录只读/运维账号，迅速执行：

```sql
-- 1. 查看当前所有正在执行的线程状态，重点观察 State 和 Time（秒）
SHOW FULL PROCESSLIST;

-- 2. 检索当前未提交的长事务
SELECT 
    trx_id, trx_state, trx_started, 
    TIMESTAMPDIFF(SECOND, trx_started, NOW()) AS duration_sec,
    trx_query 
FROM information_schema.innodb_trx 
ORDER BY duration_sec DESC LIMIT 10;

-- 3. 查看锁争用情况
SELECT * FROM sys.innodb_lock_waits;
```

### 2. 紧急止血方案
- 若发现由未命中索引的全表扫描慢 SQL（`State: Sending data` 或 `Copying to tmp table`）拖垮实例：
  ```sql
  -- 终止阻塞线程 ID（从 PROCESSLIST 查出对应 Id）
  KILL QUERY 10248;
  ```
- 若短时间内涌入海量只读统计报表请求，在网关层临时开启 URI 熔断降级。

---

## 四、SOP-03: Redis 缓存穿透、击穿与雪崩防护策略

| 故障类型 | 典型场景 | 核心防御机制 | 生产应急命令 |
| :--- | :--- | :--- | :--- |
| **缓存击穿** | 突发热点 Key（如大促爆款商品）过期瞬间，海量请求直击数据库 | **分布式互斥锁 (Mutex Key)** 或 **热点数据逻辑永不过期** | `SET lock:item:1001 uuid NX EX 5` |
| **缓存穿透** | 恶意查询数据库不存在的 ID（如 `id=-999`）绕过缓存压垮 DB | **布隆过滤器 (BloomFilter)** 或 **空值短期缓存（TTL=60s）** | 客户端增加参数合法性正则校验 |
| **缓存雪崩** | 大量 Key 设置了相同的过期时间，同一时刻集中失效 | **过期时间增加随机抖动 Jitter**（如 `TTL = 3600 + rand(0, 300)`） | 重启实例并预先批量执行暖机脚本 |

---

## 五、值班 SRE 常用速查命令
```bash
# 检查磁盘空间（防止日志爆满导致挂死）
df -hT

# 检查系统网络连接状态分布
netstat -n | awk '/^tcp/ {++S[$NF]} END {for(a in S) print a, S[a]}'
```
