-- ======================================================================
-- 电商交易与支付核心数据库 DDL 规范 (MySQL 8.0 生产级)
-- 所属系统：交易中台 (Trade & Payment Center)
-- 字符集：utf8mb4 / 存储引擎：InnoDB
-- ======================================================================

CREATE DATABASE IF NOT EXISTS `trade_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `trade_db`;

-- ----------------------------------------------------------------------
-- 1. 交易订单主表 (trade_order)
-- 包含分布式订单号、买家信息、金额明细、状态机与联合索引
-- ----------------------------------------------------------------------
DROP TABLE IF EXISTS `trade_order`;
CREATE TABLE `trade_order` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    `order_sn` VARCHAR(32) NOT NULL COMMENT '业务订单号(雪花算法全局唯一)',
    `buyer_id` BIGINT UNSIGNED NOT NULL COMMENT '买家用户ID',
    `total_amount` DECIMAL(12, 2) NOT NULL DEFAULT '0.00' COMMENT '订单总金额(未扣优惠)',
    `discount_amount` DECIMAL(12, 2) NOT NULL DEFAULT '0.00' COMMENT '优惠总抵扣金额',
    `pay_amount` DECIMAL(12, 2) NOT NULL DEFAULT '0.00' COMMENT '用户应实付金额',
    `order_status` TINYINT NOT NULL DEFAULT 10 COMMENT '状态: 10待支付, 20已支付, 30已发货, 40已完成, 50已取消, 60已退款',
    `payment_type` TINYINT NOT NULL DEFAULT 1 COMMENT '支付方式: 1微信, 2支付宝, 3银行卡, 4企业对公转账',
    `pay_time` DATETIME DEFAULT NULL COMMENT '支付到账完成时间',
    `receiver_name` VARCHAR(64) NOT NULL COMMENT '收件人姓名',
    `receiver_phone` VARCHAR(20) NOT NULL COMMENT '收件人手机号',
    `receiver_address` VARCHAR(255) NOT NULL COMMENT '详细收件地址',
    `version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '乐观锁版本号',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_order_sn` (`order_sn`),
    KEY `idx_buyer_status_ctime` (`buyer_id`, `order_status`, `created_at`),
    KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='交易订单主表';

-- ----------------------------------------------------------------------
-- 2. 订单商品明细快照表 (order_item)
-- 记录下单时的 SKU 快照单价与购买件数
-- ----------------------------------------------------------------------
DROP TABLE IF EXISTS `order_item`;
CREATE TABLE `order_item` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
    `order_sn` VARCHAR(32) NOT NULL COMMENT '关联业务订单号',
    `sku_id` BIGINT UNSIGNED NOT NULL COMMENT '商品SKU编号',
    `sku_name` VARCHAR(128) NOT NULL COMMENT '购买时商品全称快照',
    `unit_price` DECIMAL(10, 2) NOT NULL COMMENT '商品单价快照',
    `quantity` INT NOT NULL DEFAULT 1 COMMENT '购买数量',
    `subtotal` DECIMAL(12, 2) NOT NULL COMMENT '小计金额',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_order_sn` (`order_sn`),
    KEY `idx_sku_id` (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单商品明细快照表';

-- ----------------------------------------------------------------------
-- 3. 支付结算流水记录表 (payment_record)
-- 用于防重回调与第三方清结算对账
-- ----------------------------------------------------------------------
DROP TABLE IF EXISTS `payment_record`;
CREATE TABLE `payment_record` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '流水自增ID',
    `trade_no` VARCHAR(64) NOT NULL COMMENT '第三方通道交易流水号(如微信支付订单号)',
    `order_sn` VARCHAR(32) NOT NULL COMMENT '内部业务订单号',
    `channel` VARCHAR(16) NOT NULL COMMENT '支付通道: WX_PAY, ALIPAY, UNIONPAY',
    `amount` DECIMAL(12, 2) NOT NULL COMMENT '实收金额',
    `pay_status` VARCHAR(16) NOT NULL DEFAULT 'SUCCESS' COMMENT '状态: SUCCESS, FAILED, REFUND',
    `callback_raw` TEXT DEFAULT NULL COMMENT '第三方回调原始 JSON/XML 报文',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记账时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_trade_no` (`trade_no`),
    KEY `idx_order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='第三方支付结算流水记录表';
