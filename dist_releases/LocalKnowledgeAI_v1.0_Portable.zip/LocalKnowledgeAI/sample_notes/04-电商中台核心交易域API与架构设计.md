# 💻 电商中台核心交易域 API 与架构设计

> **适用角色**：全栈开发工程师、后台微服务架构师、前端开发  
> **关联文档**：`[[05-交易与结算核心数据库DDL.sql]]`、`[[06-微服务全栈容器编排规范.yaml]]`

---

## 一、核心业务时序图（订单履约全流程）

```mermaid
sequenceDiagram
    autonumber
    actor Client as 用户端 App/H5
    participant Gateway as API 网关
    participant OrderSvc as 订单中心 (Order Service)
    participant StockSvc as 库存中心 (Stock Service)
    participant PaySvc as 支付网关 (Pay Service)
    
    Client->>Gateway: POST /api/v1/orders/create (携带 Idempotency-Token)
    Gateway->>OrderSvc: 转发下单请求
    OrderSvc->>StockSvc: RPC: 预扣减库存 (Freeze Stock)
    StockSvc-->>OrderSvc: 预扣成功
    OrderSvc->>OrderSvc: 插入 trade_order 表 (状态: WAIT_PAY)
    OrderSvc->>PaySvc: 创建预支付单据
    PaySvc-->>Client: 返回调起微信/支付宝支付凭证
    Client->>PaySvc: 完成支付
    PaySvc->>OrderSvc: Webhook: 支付成功异步回调
    OrderSvc->>OrderSvc: 更新订单状态为 PAID (已支付)
    OrderSvc->>StockSvc: RPC: 确认扣减真实库存
    OrderSvc-->>Client: WebSocket / 轮询通知: 支付完成
```

---

## 二、订单状态机流转说明

系统使用整型代码维护订单生命周期状态，严格禁止逆向流转：

- `10 - WAIT_PAY`（待支付）：买家提交订单成功，等待付款。超时 15 分钟未支付自动关闭。
- `20 - PAID`（已支付）：第三方支付回调成功，等待仓库打单发货。
- `30 - SHIPPED`（已发货）：物流运单号已绑定，快递承运揽收中。
- `40 - FINISHED`（已完成）：买家主动确认收货或系统超时 7 天自动确认完成。
- `50 - CANCELLED`（已取消）：超时未付或买家在未支付前主动取消。
- `60 - REFUNDED`（已退款）：售后申请审核通过并全额原路退款。

---

## 三、核心 RESTful API 规范

### 1. 提交订单接口
- **URL**: `POST /api/v1/orders/create`
- **Headers**:
  - `Content-Type: application/json`
  - `Authorization: Bearer <JWT_TOKEN>`
  - `X-Idempotency-Key: <UUID>`（防重复点击下单）

#### 请求体示例 (JSON):
```json
{
  "buyer_id": 880291,
  "client_ip": "192.168.1.108",
  "items": [
    {
      "sku_id": 100234,
      "quantity": 2,
      "unit_price": 199.00
    },
    {
      "sku_id": 100588,
      "quantity": 1,
      "unit_price": 89.00
    }
  ],
  "shipping_address": {
    "receiver_name": "张三",
    "phone": "13800138000",
    "province": "上海市",
    "city": "上海市",
    "district": "浦东新区",
    "detail": "张江高科技园区博云路2号"
  },
  "coupon_id": "CPN_2026_DISCOUNT_20"
}
```

#### 成功响应示例 (JSON):
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "order_sn": "ORD202611040920110001",
    "total_amount": 487.00,
    "discount_amount": 20.00,
    "pay_amount": 467.00,
    "status": 10,
    "status_desc": "WAIT_PAY",
    "expire_seconds": 900,
    "pay_channel_payload": {
      "app_id": "wx88888888",
      "prepay_id": "wx0409201138290123",
      "sign": "E10ADC3949BA59ABBE56E057F20F883E"
    }
  }
}
```

---

## 四、高并发与分布式一致性保障
1. **防重提交机制**：Redis 缓存 `X-Idempotency-Key`，TTL 设置为 30 秒，重复请求直接返回 `409 Conflict`。
2. **库存防超卖**：采用 Redis Lua 脚本原子性预扣减库存，校验通过后再入库。
3. **数据库事务与幂等**：支付回调接口基于 `payment_record` 唯一流水号 `trade_no` 做唯一性约束。
