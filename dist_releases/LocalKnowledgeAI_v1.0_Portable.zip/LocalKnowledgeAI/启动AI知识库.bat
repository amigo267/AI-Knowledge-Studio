@echo off
cd /d "%~dp0"
start "" "LocalKnowledgeAI.exe"
